package com.movierandomizer.movieInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
